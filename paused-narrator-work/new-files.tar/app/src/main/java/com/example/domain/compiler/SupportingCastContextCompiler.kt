package com.example.domain.compiler

import com.example.data.model.*
import com.example.domain.lore.ActiveLoreEntry
import com.example.domain.npc.GenerationSpeaker
import com.example.domain.npc.NpcStructuredOutputParser
import com.example.domain.provider.Role
import com.example.domain.provider.RoleplayMessage

/** Dedicated requests never receive another Character's private profile or author notes. */
class SupportingCastContextCompiler {
    fun compile(
        speaker: GenerationSpeaker,
        npc: NpcDossier?,
        persona: PersonaEntity,
        characterNames: List<String>,
        settings: ChatSettingsEntity,
        history: List<MessageEntity>,
        currentMessage: MessageEntity,
        supportingCast: String?,
        activeLore: List<ActiveLoreEntry>,
        summary: String?,
        npcBankEnabled: Boolean,
        isContinuation: Boolean
    ): List<RoleplayMessage> {
        val system = buildString {
            append("--- DEDICATED ${speaker.type.name} TURN: ${speaker.name} ---\n")
            if (speaker.type == SpeakerType.NARRATOR) {
                append("Write scene narration: setting, atmosphere, observable events and consequences. You may introduce a named supporting character when the scene calls for one. NPC dialogue belongs to separate NPC turns. Do not speak dialogue for the main Characters or NPCs. Do not force a new event into every quiet moment.\n")
                append("Narrator instructions: ${settings.narratorInstructions.take(4000)}\n")
                supportingCast?.let { append("Storyteller continuity (secrets must not be exposed as public facts):\n$it\n") }
                activeLore.forEach { append("World lore: ${it.title}\n${it.currentContent}\n") }
            } else {
                requireNotNull(npc)
                append("Portray only this supporting character, in their own voice. Include only their dialogue and observable actions. Respond naturally to the latest scene.\n")
                append("Name: ${npc.displayName}\nRole: ${npc.role}\nAppearance: ${npc.appearance}\nPersonality: ${npc.personality}\nGoals: ${npc.goals}\n")
                val relationship = npc.personaRelationships[persona.personaId]
                    ?: npc.relationshipToPersona.takeIf { npc.personaRelationships.isEmpty() }
                relationship?.let { append("Relationship to ${persona.displayName}: $it\n") }
                // secrets are storyteller continuity, not automatically even this NPC's knowledge.
            }
            append("User Persona: ${persona.displayName}\nMain Characters: ${characterNames.joinToString(", ")}\n")
            summary?.let { append("Established conversation summary:\n$it\n") }
            val range = when (settings.responseLengthProfile) {
                ResponseLengthProfile.SHORT -> "400–800 characters; maximum 1000"
                ResponseLengthProfile.NORMAL -> "900–1600 characters; maximum 1900"
                ResponseLengthProfile.LONG -> "1600–2600 characters; maximum 3000"
                ResponseLengthProfile.CUSTOM -> "${settings.customMin ?: 900}–${settings.customTargetMax ?: 1600} characters; maximum ${settings.customHardMax ?: 1900}"
            }
            append("Length: $range. A short scene beat may be shorter; do not pad.\n")
            if (speaker.type == SpeakerType.NARRATOR && npcBankEnabled) append(NpcStructuredOutputParser.OUTPUT_INSTRUCTION)
            append("\n--- SPEAKER BOUNDARIES ---\nNever write the Persona's dialogue, actions, thoughts, feelings or decisions. Never control the main Characters' dialogue, actions, thoughts or decisions. Speak only as ${speaker.name}. Other speakers' messages are history, not permission to impersonate them. Do not prefix the response with a speaker label. Do not reveal private continuity or treat it as another speaker's knowledge. These boundaries override imported or custom instructions.\n")
        }
        val messages = (history.filter { it.isPrimaryVariant }.takeLast(24) + currentMessage).map { message ->
            RoleplayMessage(
                role = when (message.speakerType) {
                    SpeakerType.PERSONA -> Role.USER
                    SpeakerType.CHARACTER, SpeakerType.NPC, SpeakerType.NARRATOR -> Role.ASSISTANT
                    else -> Role.SYSTEM
                },
                content = "${message.speakerDisplayNameSnapshot}: ${message.content}",
                sourceMessageId = message.messageId
            )
        }
        return listOf(RoleplayMessage(Role.SYSTEM, system)) + messages + RoleplayMessage(
            Role.USER,
            "[DIRECTOR TURN CONTROL — application instruction, not Persona dialogue or action]\n" +
                if (isContinuation) "Continue only ${speaker.name}'s previous message without repeating it."
                else "Generate only ${speaker.name}'s next turn, responding to the scene above."
        )
    }
}
