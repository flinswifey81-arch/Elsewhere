package com.example.domain.npc

import com.example.data.model.MessageEntity
import com.example.data.model.NpcDossier
import com.example.data.model.SpeakerType

data class GenerationSpeaker(val id: String, val name: String, val type: SpeakerType) {
    companion object {
        fun narrator(chatId: String) = GenerationSpeaker("narrator:$chatId", "Narrator", SpeakerType.NARRATOR)
    }
}

object SupportingCastPlanner {
    const val MAX_AUTOMATIC_NPCS = 2

    /** A bank entry alone is not evidence that someone is in this scene. */
    fun select(dossiers: List<NpcDossier>, history: List<MessageEntity>, limit: Int = MAX_AUTOMATIC_NPCS): List<NpcDossier> {
        val recentText = history.filter { it.isPrimaryVariant }.takeLast(4).joinToString("\n") { it.content }
        return dossiers.map { npc ->
            val mentions = (listOf(npc.displayName) + npc.aliases).filter(String::isNotBlank).sumOf { name ->
                Regex("(?i)(?<![\\p{L}\\p{N}_])${Regex.escape(name)}(?![\\p{L}\\p{N}_])").findAll(recentText).count()
            }
            npc to (mentions * 20 + if (npc.keepInScene) 1000 else 0)
        }.filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<NpcDossier, Int>> { it.second }.thenBy { it.first.npcId })
            .take(limit.coerceIn(0, 8)).map { it.first }
    }
}
