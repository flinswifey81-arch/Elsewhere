package com.example

import com.example.data.model.*
import com.example.domain.npc.SupportingCastPlanner
import org.junit.Assert.*
import org.junit.Test

class SupportingCastPlannerTest {
    @Test fun absentNpcsDoNotJoinAndPartialNamesDoNotCountAsMentions() {
        val history = listOf(message("Arthur enters the hall."))
        assertEquals(listOf("Arthur"), SupportingCastPlanner.select(listOf(npc("Art"), npc("Arthur"), npc("Beth")), history).map { it.displayName })
        assertTrue(SupportingCastPlanner.select(listOf(npc("Beth")), history).isEmpty())
    }

    @Test fun pinnedAndMentionedNpcsAreBoundedAndUnselectedVariantsDoNotCount() {
        val history = listOf(message("Arthur, Beth and Cael.").copy(isPrimaryVariant = false))
        assertTrue(SupportingCastPlanner.select(listOf(npc("Arthur")), history).isEmpty())
        val selected = SupportingCastPlanner.select(listOf(npc("Arthur", true), npc("Beth", true), npc("Cael", true)), emptyList())
        assertEquals(2, selected.size)
        assertEquals(listOf("Arthur", "Beth"), selected.map { it.displayName })
    }

    private fun message(content: String) = MessageEntity(chatId = "chat", speakerType = SpeakerType.PERSONA,
        speakerId = "persona", speakerDisplayNameSnapshot = "Persona", content = content, orderIndex = 1)

    private fun npc(name: String, pinned: Boolean = false) = NpcDossier(name, "chat", name, emptyList(),
        "", "", "", "", emptyMap(), emptyMap(), "", "", "", pinned, true, 1, 1)
}
