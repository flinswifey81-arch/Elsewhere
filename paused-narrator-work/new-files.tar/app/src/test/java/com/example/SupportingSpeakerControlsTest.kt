package com.example

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.model.*
import com.example.domain.npc.GenerationSpeaker
import com.example.ui.screens.ChatUiState
import com.example.ui.screens.SupportingSpeakerControls
import com.example.ui.theme.AppTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(AndroidJUnit4::class)
@Config(manifest = Config.NONE)
class SupportingSpeakerControlsTest {
    @get:Rule val compose = createComposeRule()

    @Test fun manualMenuSelectsExactNpcIdentity() {
        var selected: GenerationSpeaker? = null
        compose.setContent { AppTheme { SupportingSpeakerControls(state()) { selected = it } } }
        compose.onNodeWithText("Choose next speaker").performClick()
        compose.onNodeWithText("Narrator · Narrator").assertExists()
        compose.onNodeWithText("Arthur · Npc").performClick()
        assertEquals(GenerationSpeaker("arthur", "Arthur", SpeakerType.NPC), selected)
    }

    @Test fun menuIsDisabledBetweenAutomaticRequests() {
        compose.setContent { AppTheme { SupportingSpeakerControls(state().copy(automaticTurnRunning = true)) {} } }
        compose.onNodeWithText("Choose next speaker").assertIsNotEnabled()
    }

    private fun state() = ChatUiState.Success(
        chatSummary = ChatSummary(ChatEntity(chatId = "chat", displayName = "Scene", chatType = ChatType.SOLO), emptyList(), emptyList()),
        messages = listOf(MessageEntity(chatId = "chat", speakerType = SpeakerType.PERSONA, speakerId = "persona",
            speakerDisplayNameSnapshot = "Persona", content = "Hello", orderIndex = 1)),
        chatSettings = ChatSettingsEntity(chatId = "chat", narratorEnabled = true),
        historyLoaded = true,
        npcBankEnabled = true,
        npcDossiers = listOf(NpcDossier("arthur", "chat", "Arthur", emptyList(), "", "", "", "", emptyMap(), emptyMap(), "", "", "", true, true, 1, 1))
    )
}
